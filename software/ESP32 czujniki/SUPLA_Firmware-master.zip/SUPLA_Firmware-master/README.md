# GUI Generic
Supla for ESP8266 and ESP8285</br>

https://forum.supla.org/viewtopic.php?f=11&t=7133
-------------------------------------------------

Initial parameters for "NodeMCU PyFlasher":

Flash mode DOUT

-------------------------------------------------

Initial parameters for "ESP Flash Download Tool":

CrystalFreq    26M

SPI SPEED       40MHz

SPI MODE        DOUT

BAUDRATE        115200

FLASH SIZE 8Mbit (1MByte)

GUI_Generic.bin-------->0x00000

